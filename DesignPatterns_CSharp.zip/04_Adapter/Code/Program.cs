using System;

public interface IPaymentProcessor { void ProcessPayment(); }
public class PayPalGateway { public void SendMoney() => Console.WriteLine("Sending money via PayPal"); }
public class PayPalAdapter : IPaymentProcessor
{
    private PayPalGateway gateway;
    public PayPalAdapter(PayPalGateway gateway) => this.gateway = gateway;
    public void ProcessPayment() => gateway.SendMoney();
}

class Program
{
    static void Main()
    {
        var gateway = new PayPalGateway();
        IPaymentProcessor processor = new PayPalAdapter(gateway);
        processor.ProcessPayment();
    }
}