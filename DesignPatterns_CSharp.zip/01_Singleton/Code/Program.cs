using System;

public class Logger
{
    private static Logger? _instance;
    private Logger() => Console.WriteLine("Logger initialized");
    public static Logger GetInstance() => _instance ??= new Logger();
    public void Log(string message) => Console.WriteLine($"Log: {message}");
}

class Program
{
    static void Main(string[] args)
    {
        Logger logger1 = Logger.GetInstance();
        logger1.Log("First message");

        Logger logger2 = Logger.GetInstance();
        logger2.Log("Second message");

        Console.WriteLine("Same instance? " + (logger1 == logger2));
    }
}