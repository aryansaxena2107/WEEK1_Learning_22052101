using System;

public class Student
{
    public string Name { get; set; }
    public int Id { get; set; }
    public string Grade { get; set; }
}

public class StudentView
{
    public void DisplayStudentDetails(Student s)
    {
        Console.WriteLine($"Student: {s.Name}, ID: {s.Id}, Grade: {s.Grade}");
    }
}

public class StudentController
{
    private Student model;
    private StudentView view;

    public StudentController(Student model, StudentView view)
    {
        this.model = model;
        this.view = view;
    }

    public void SetName(string name) => model.Name = name;
    public void UpdateView() => view.DisplayStudentDetails(model);
}

class Program
{
    static void Main()
    {
        var student = new Student { Name = "Aryan", Id = 1, Grade = "A" };
        var view = new StudentView();
        var controller = new StudentController(student, view);
        controller.UpdateView();
        controller.SetName("Priya");
        controller.UpdateView();
    }
}