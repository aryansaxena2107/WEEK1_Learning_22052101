using System;

public interface IImage { void Display(); }

public class RealImage : IImage
{
    private string filename;
    public RealImage(string filename)
    {
        this.filename = filename;
        LoadFromDisk();
    }

    private void LoadFromDisk() => Console.WriteLine($"Loading {filename}");
    public void Display() => Console.WriteLine($"Displaying {filename}");
}

public class ProxyImage : IImage
{
    private RealImage? realImage;
    private string filename;

    public ProxyImage(string filename) => this.filename = filename;

    public void Display()
    {
        if (realImage == null)
            realImage = new RealImage(filename);
        realImage.Display();
    }
}

class Program
{
    static void Main()
    {
        IImage image = new ProxyImage("photo.jpg");
        image.Display();
        image.Display();
    }
}