using System;

public interface ICommand { void Execute(); }

public class Light
{
    public void On() => Console.WriteLine("Light ON");
    public void Off() => Console.WriteLine("Light OFF");
}

public class LightOnCommand : ICommand
{
    private Light light;
    public LightOnCommand(Light light) => this.light = light;
    public void Execute() => light.On();
}

public class LightOffCommand : ICommand
{
    private Light light;
    public LightOffCommand(Light light) => this.light = light;
    public void Execute() => light.Off();
}

public class RemoteControl
{
    private ICommand command;
    public RemoteControl(ICommand command) => this.command = command;
    public void PressButton() => command.Execute();
}

class Program
{
    static void Main()
    {
        Light light = new Light();
        var remote = new RemoteControl(new LightOnCommand(light));
        remote.PressButton();
        remote = new RemoteControl(new LightOffCommand(light));
        remote.PressButton();
    }
}