using System;
using System.Collections.Generic;

public interface IObserver { void Update(string stock, double price); }

public class MobileApp : IObserver
{
    public void Update(string stock, double price) =>
        Console.WriteLine($"Mobile App: {stock} is now {price}");
}

public class StockMarket
{
    private List<IObserver> observers = new();
    public void Register(IObserver o) => observers.Add(o);
    public void Notify(string stock, double price)
    {
        foreach (var o in observers) o.Update(stock, price);
    }
}

class Program
{
    static void Main()
    {
        var market = new StockMarket();
        market.Register(new MobileApp());
        market.Notify("AAPL", 150.5);
    }
}