using System;

public interface IPaymentStrategy { void Pay(); }
public class CreditCardPayment : IPaymentStrategy { public void Pay() => Console.WriteLine("Paid with Credit Card."); }
public class PayPalPayment : IPaymentStrategy { public void Pay() => Console.WriteLine("Paid with PayPal."); }

public class PaymentContext
{
    private IPaymentStrategy strategy;
    public PaymentContext(IPaymentStrategy strategy) => this.strategy = strategy;
    public void ExecutePayment() => strategy.Pay();
}

class Program
{
    static void Main()
    {
        var context = new PaymentContext(new CreditCardPayment());
        context.ExecutePayment();
        context = new PaymentContext(new PayPalPayment());
        context.ExecutePayment();
    }
}