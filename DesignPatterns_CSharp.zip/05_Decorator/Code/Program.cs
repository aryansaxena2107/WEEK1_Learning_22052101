using System;

public interface INotifier { void Send(); }
public class EmailNotifier : INotifier { public void Send() => Console.WriteLine("Sending Email Notification..."); }

public abstract class NotifierDecorator : INotifier
{
    protected INotifier notifier;
    public NotifierDecorator(INotifier notifier) => this.notifier = notifier;
    public virtual void Send() => notifier.Send();
}

public class SMSNotifier : NotifierDecorator
{
    public SMSNotifier(INotifier notifier) : base(notifier) { }
    public override void Send()
    {
        base.Send();
        Console.WriteLine("Sending SMS Notification...");
    }
}

class Program
{
    static void Main()
    {
        INotifier notifier = new SMSNotifier(new EmailNotifier());
        notifier.Send();
    }
}