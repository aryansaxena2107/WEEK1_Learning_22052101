using System;

public interface ICustomerRepository
{
    string FindCustomerById(int id);
}

public class CustomerRepository : ICustomerRepository
{
    public string FindCustomerById(int id) => $"Customer #{id}";
}

public class CustomerService
{
    private ICustomerRepository repository;
    public CustomerService(ICustomerRepository repository) => this.repository = repository;
    public void DisplayCustomer(int id) => Console.WriteLine(repository.FindCustomerById(id));
}

class Program
{
    static void Main()
    {
        ICustomerRepository repo = new CustomerRepository();
        var service = new CustomerService(repo);
        service.DisplayCustomer(1);
    }
}