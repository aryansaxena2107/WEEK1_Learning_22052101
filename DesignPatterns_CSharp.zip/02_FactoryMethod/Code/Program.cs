using System;

public interface IDocument { void Open(); }
public class WordDocument : IDocument { public void Open() => Console.WriteLine("Opening Word Document"); }
public abstract class DocumentFactory { public abstract IDocument CreateDocument(); }
public class WordDocumentFactory : DocumentFactory { public override IDocument CreateDocument() => new WordDocument(); }

class Program
{
    static void Main()
    {
        DocumentFactory factory = new WordDocumentFactory();
        IDocument doc = factory.CreateDocument();
        doc.Open();
    }
}