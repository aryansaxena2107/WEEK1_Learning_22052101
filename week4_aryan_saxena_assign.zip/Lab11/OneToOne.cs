// Solution content for Lab11/OneToOne.cs
