// Solution content for Lab12/ProjectionToDTO.cs
