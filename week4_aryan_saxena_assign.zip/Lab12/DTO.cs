// Solution content for Lab12/DTO.cs
