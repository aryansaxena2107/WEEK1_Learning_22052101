// Solution content for Lab10/LoadingStrategies.cs
