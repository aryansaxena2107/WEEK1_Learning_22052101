// Solution content for Lab4/InsertData.cs
