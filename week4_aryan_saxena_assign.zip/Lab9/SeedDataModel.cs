// Solution content for Lab9/SeedDataModel.cs
