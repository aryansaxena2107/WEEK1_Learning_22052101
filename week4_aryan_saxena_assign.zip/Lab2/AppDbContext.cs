// Solution content for Lab2/AppDbContext.cs
