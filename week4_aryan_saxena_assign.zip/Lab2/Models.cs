// Solution content for Lab2/Models.cs
