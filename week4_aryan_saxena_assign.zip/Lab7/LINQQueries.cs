// Solution content for Lab7/LINQQueries.cs
