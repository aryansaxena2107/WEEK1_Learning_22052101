// Solution content for Lab13/QueryOptimization.cs
