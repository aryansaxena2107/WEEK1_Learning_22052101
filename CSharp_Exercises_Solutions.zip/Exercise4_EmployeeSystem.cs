using System;

public class Employee
{
    public string EmployeeId { get; set; }
    public string Name { get; set; }
    public string Position { get; set; }
    public double Salary { get; set; }

    public Employee(string id, string name, string pos, double salary)
    {
        EmployeeId = id;
        Name = name;
        Position = pos;
        Salary = salary;
    }
}

public class EmployeeManager
{
    private Employee[] employees = new Employee[100];
    private int count = 0;

    public void Add(Employee emp)
    {
        if (count < employees.Length)
            employees[count++] = emp;
    }

    public Employee? Search(string id)
    {
        for (int i = 0; i < count; i++)
            if (employees[i].EmployeeId == id)
                return employees[i];
        return null;
    }

    public void Traverse()
    {
        for (int i = 0; i < count; i++)
            Console.WriteLine(employees[i].Name);
    }

    public void Delete(string id)
    {
        for (int i = 0; i < count; i++)
        {
            if (employees[i].EmployeeId == id)
            {
                for (int j = i; j < count - 1; j++)
                    employees[j] = employees[j + 1];
                count--;
                return;
            }
        }
    }
}