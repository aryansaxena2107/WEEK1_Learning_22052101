using System;

public class Order
{
    public string OrderId { get; set; }
    public string CustomerName { get; set; }
    public double TotalPrice { get; set; }

    public Order(string id, string name, double price)
    {
        OrderId = id;
        CustomerName = name;
        TotalPrice = price;
    }
}

public class OrderSorter
{
    public static void BubbleSort(Order[] orders)
    {
        for (int i = 0; i < orders.Length - 1; i++)
            for (int j = 0; j < orders.Length - i - 1; j++)
                if (orders[j].TotalPrice > orders[j + 1].TotalPrice)
                    (orders[j], orders[j + 1]) = (orders[j + 1], orders[j]);
    }

    public static void QuickSort(Order[] orders, int low, int high)
    {
        if (low < high)
        {
            int pi = Partition(orders, low, high);
            QuickSort(orders, low, pi - 1);
            QuickSort(orders, pi + 1, high);
        }
    }

    private static int Partition(Order[] orders, int low, int high)
    {
        var pivot = orders[high].TotalPrice;
        int i = low - 1;
        for (int j = low; j < high; j++)
            if (orders[j].TotalPrice < pivot)
                (orders[++i], orders[j]) = (orders[j], orders[i]);
        (orders[i + 1], orders[high]) = (orders[high], orders[i + 1]);
        return i + 1;
    }
}