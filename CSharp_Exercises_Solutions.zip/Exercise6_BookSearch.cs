using System;

public class Book
{
    public string BookId { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }

    public Book(string id, string title, string author)
    {
        BookId = id;
        Title = title;
        Author = author;
    }
}

public class BookSearch
{
    public static Book? LinearSearch(Book[] books, string title)
    {
        foreach (var book in books)
            if (book.Title == title)
                return book;
        return null;
    }

    public static Book? BinarySearch(Book[] books, string title)
    {
        int low = 0, high = books.Length - 1;
        while (low <= high)
        {
            int mid = (low + high) / 2;
            int cmp = string.Compare(books[mid].Title, title);
            if (cmp == 0) return books[mid];
            else if (cmp < 0) low = mid + 1;
            else high = mid - 1;
        }
        return null;
    }
}