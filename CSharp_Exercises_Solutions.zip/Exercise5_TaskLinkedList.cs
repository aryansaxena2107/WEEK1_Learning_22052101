using System;

public class Task
{
    public string TaskId { get; set; }
    public string TaskName { get; set; }
    public string Status { get; set; }
    public Task? Next { get; set; }

    public Task(string id, string name, string status)
    {
        TaskId = id;
        TaskName = name;
        Status = status;
    }
}

public class TaskList
{
    private Task? head;

    public void Add(Task task)
    {
        task.Next = head;
        head = task;
    }

    public Task? Search(string id)
    {
        Task? current = head;
        while (current != null)
        {
            if (current.TaskId == id) return current;
            current = current.Next;
        }
        return null;
    }

    public void Traverse()
    {
        Task? current = head;
        while (current != null)
        {
            Console.WriteLine(current.TaskName);
            current = current.Next;
        }
    }

    public void Delete(string id)
    {
        Task? current = head, prev = null;
        while (current != null)
        {
            if (current.TaskId == id)
            {
                if (prev == null) head = current.Next;
                else prev.Next = current.Next;
                return;
            }
            prev = current;
            current = current.Next;
        }
    }
}