using System;
using System.Collections.Generic;

public class Product
{
    public string ProductId { get; set; }
    public string ProductName { get; set; }
    public int Quantity { get; set; }
    public double Price { get; set; }

    public Product(string productId, string productName, int quantity, double price)
    {
        ProductId = productId;
        ProductName = productName;
        Quantity = quantity;
        Price = price;
    }
}

public class InventorySystem
{
    private Dictionary<string, Product> inventory = new Dictionary<string, Product>();

    public void AddProduct(Product product) => inventory[product.ProductId] = product;

    public void UpdateProduct(string productId, int quantity, double price)
    {
        if (inventory.ContainsKey(productId))
        {
            var product = inventory[productId];
            product.Quantity = quantity;
            product.Price = price;
        }
    }

    public void DeleteProduct(string productId) => inventory.Remove(productId);

    public Product? GetProduct(string productId)
    {
        inventory.TryGetValue(productId, out Product? product);
        return product;
    }

    public void DisplayAllProducts()
    {
        foreach (var product in inventory.Values)
            Console.WriteLine($"ID: {product.ProductId}, Name: {product.ProductName}, Quantity: {product.Quantity}, Price: {product.Price}");
    }
}

class Program
{
    static void Main()
    {
        InventorySystem system = new InventorySystem();
        system.AddProduct(new Product("P001", "Laptop", 10, 75000));
        system.AddProduct(new Product("P002", "Mouse", 50, 500));
        system.UpdateProduct("P001", 8, 74000);
        system.DeleteProduct("P002");

        var found = system.GetProduct("P001");
        if (found != null)
            Console.WriteLine($"Found: {found.ProductName} - {found.Quantity} pcs");

        system.DisplayAllProducts();
    }
}